import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { Observable } from 'rxjs';
import * as Rx from 'rxjs';
import { delay, shareReplay } from "rxjs/operators";
@Component({
  selector: 'app-component3',
  templateUrl: './component3.component.html',
  styleUrls: ['./component3.component.scss']
})
export class Component3Component implements OnInit {
  api: any;
  columnApi: any;
  columnDefs: ColDef[] = [];
  rowData: any = [];
  constructor(
    private _httpClient: HttpClient
  ) { }

  ngOnInit(): void {

  }
  navigatePage() {
    this.api.showLoadingOverlay();
    this.columnDefs = [
      { field: 'userId' },
      { field: 'id' },
      { field: 'title' },
      { field: 'body' }
    ]
    this._httpClient
      .get('https://jsonplaceholder.typicode.com/posts')
      .pipe(delay(5000))      
      .subscribe((response) => {
        this.rowData = response;
      }).add(() => {
        this.api.hideOverlay();
      })

  }
  onGridReady = (params: any) => {
    this.api = params.api;
    this.columnApi = params.columnApi;
    this.api.showNoRowsOverlay();
  }
}
 

