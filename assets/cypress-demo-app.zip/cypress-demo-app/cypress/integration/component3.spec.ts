describe('Testing Component 3 Using Cypress Features', () => {
    it('Should load the load Route ', () => {
        cy.visit('/load')
        cy.get("[id='load']").invoke('text').should('equal', 'Load Data On Click')
    })

    it('Should have the ag grid in visible mode with No More Rows', () => {
        cy.visit('/load')
        cy.get('.ag-root-wrapper').should('be.visible');
        cy.get("span[class='ag-overlay-no-rows-center']").invoke('text').should('eq', 'No Rows To Show');
    })


    it('Should Click on the Load Data Button and Get Data on', () => {
        cy.visit('/load');
        cy.get("[id='load']").click();
        
        cy.get("span[class='ag-overlay-loading-center']").invoke('text').should('eq', 'Loading...');
        // cy.intercept({
        //     method: "GET",
        //     url: "https://jsonplaceholder.typicode.com/posts",
        // }).as("getPostData");
        cy.wait(5000);
        cy.get('.ag-cell').should('be.visible');
        let columnName = [];
        cy.get("span[class='ag-header-cell-text']").each(($el) => {
            columnName.push($el[0].innerText);
          }).then(() => {
            expect(columnName.length).not.to.eq(0);
            expect(columnName.length).to.eq(4);
          });
    })
})
