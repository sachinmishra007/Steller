describe('Testing Component 1 Using Cypress Features', () => {
  it('Visits the initial project page', () => {
    cy.visit('/')
    cy.contains('Welcome')
    cy.contains('Welcome to dashboard Component')
    cy.get("[id='goto']").invoke('text').should('equal', 'Goto Dashboard')
  })

  it('Should Click on the Goto Dashboard Button and Load Dashboard Page', () => {
    cy.visit('/')
    cy.contains('Welcome to dashboard Component')
    cy.get("[id='goto']").click();
    cy.url().should('contain', 'main');
  })

  it('Should load the Component 2 when user nagigate to Main Dashborad Component', () => {
    cy.visit('/')
    cy.contains('Welcome to dashboard Component')
    cy.get("[id='goto']").click();
    cy.get("[class='username']").invoke('text').should('eq', 'User Name');
    cy.get("[class='username-opt']").find('option').should('have.length.gt', 0);
  })

  it('Should Test the Ag Grid with title', () => {
    cy.log("------------- Loading Ag Grid --------------");
    cy.visit('/')
    cy.get("[id='goto']").click();
    cy.get('.ag-cell').should('be.visible');
    let columnName = [];
    let checkEmailId = [];
    cy.get("span[class='ag-header-cell-text']").each(($el) => {
      columnName.push($el[0].innerText);
    }).then(() => {
      expect(columnName.length).not.to.eq(0);
      expect(columnName.length).to.eq(5);
    });

    // Check for the  
    cy.get("div[col-id='email']").each(($el) => {
      checkEmailId.push($el[0].innerText);
    }).then(() => {
      expect(columnName.length).not.to.eq(0);      
    });

  })

})
